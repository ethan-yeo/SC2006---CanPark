import 'package:google_places_flutter/google_places_flutter.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_places_flutter/model/prediction.dart';
import 'package:parking/screens/home.dart';
import 'package:parking/controller/locationService.dart';
import 'package:parking/screens/FilterPreferences.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:parking/constants/constant.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
bool containsSubstringBitByBit(String searchString, List<String> stringList) {
  for (int i = 0; i < searchString.length; i++) {
    for (int j = i + 1; j <= searchString.length; j++) {
      String substring = searchString.substring(i, j);
      if (stringList.any((element) => element.contains(substring))) {
        return true;
      }
    }
  }
  return false;
}
  String? _validateInput(String? value) {
    List<String> towns = [
    'Ang Mo Kio',
    'Bedok',
    'Bishan',
    'Bukit Batok',
    'Bukit Merah',
    'Bukit Panjang',
    'Bukit Timah',
    'Central Water Catchment',
    'Changi',
    'Choa Chu Kang',
    'Clementi',
    'Downtown Core',
    'Geylang',
    'Hougang',
    'Jurong East',
    'Jurong West',
    'Kallang',
    'Lim Chu Kang',
    'Mandai',
    'Marine Parade',
    'Museum',
    'Newton',
    'North-Eastern Islands',
    'Novena',
    'Orchard',
    'Outram',
    'Pasir Ris',
    'Paya Lebar',
    'Pioneer',
    'Punggol',
    'Queenstown',
    'River Valley',
    'Rochor',
    'Seletar',
    'Sembawang',
    'Sengkang',
    'Serangoon',
    'Simpang',
    'Singapore River',
    'Southern Islands',
    'Straits View',
    'Sungei Kadut',
    'Tampines',
    'Tanglin',
    'Tengah',
    'Toa Payoh',
    'Tuas',
    'Western Islands',
    'Western Water Catchment',
    'Woodlands',
    'Yishun',
  ];
      bool inputContain = containsSubstringBitByBit(value!, towns);
    
    if (containsSymbols(value!)) {
      return 'Invalid address keyed (No symbols allowed). Please retry with a valid address';
    }

    else if (value.isEmpty) {
      return 'Invalid address keyed (Empty input given). Please retry with a valid address';
    }
    else if (inputContain==false){
      return 'Invalid address keyed (Not a town of Singapore). Please retry with a valid address';
    }
    // Add more validation logic if needed
    return null;
  }
  bool containsSymbols(String value){
    List<String> symbolList = ['@', '~', '\$', '!', '%', '*', '+', '_', '=', '{', '}', '[', ']' ];
    return symbolList.any((symbol)=>value.contains(symbol));
  }
  Completer<GoogleMapController> _controller = Completer();
  TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          SizedBox(
            width: 55,
          ),
          Flexible(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: GooglePlaceAutoCompleteTextField(
                textEditingController:_searchController,
                googleAPIKey: google_api_key,
                inputDecoration: InputDecoration(
                  hintText: "Search your location",
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  iconColor: Colors.white,
                ),
                countries: ['sg'],
                getPlaceDetailWithLatLng: (Prediction prediction) {
                  print("placeDetails" + prediction.lat.toString());
                },
                itemClick: (prediction){
                  _searchController.text= prediction.description!;
                },        
                debounceTime: 300,
              textStyle: TextStyle(color: Colors.black), // Set text color
                 )
            ),
          ),
          IconButton(
            onPressed: () async {
              String? error = _validateInput(_searchController.text);

              if (error == null) {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                var place = await LocationService().getPlace(_searchController.text);
                await prefs.setDouble('clickLat', place['geometry']['location']['lat']);
                await prefs.setDouble('clickLng', place['geometry']['location']['lng']);
                await prefs.setInt('selector', 1);
                savePlaceLocally('place1', place);
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen()));
              } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Input Error'),
                        content: Text(error),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('I have noted the error in my input.'),
                          ),
                        ],
                      );
                    },
                  );
                _searchController.clear();

              }
            },
            icon: Icon(Icons.search),
          ),
          IconButton(
            onPressed: () async {
              final route = MaterialPageRoute(
                builder: (context) => const FilterPreferences(),
              );
              Navigator.push(context, route);
            },
            icon: Icon(IconData(0xe976, fontFamily: 'MaterialIcons')),
          ),
        ],
      ),
    );
  }
}
    
  