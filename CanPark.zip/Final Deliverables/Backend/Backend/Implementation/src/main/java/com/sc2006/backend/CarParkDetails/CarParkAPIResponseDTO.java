package com.sc2006.backend.CarParkDetails;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CarParkAPIResponseDTO {

    @JsonProperty("odata_metadata")
    private String odata_metadata;

    @JsonProperty("value")
    private List<CarParkDTO> value;

    public List<CarParkDTO> getValue() {
        return value;
    }
    
}
