package com.sc2006.backend.Preference;

import com.sc2006.backend.User.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Optional;

@RestController
@RequestMapping("/preference")
public class PreferenceController {
    @Autowired
    private UserService userService;

    @Autowired
    private PreferenceService preferenceService;

    @GetMapping("/{userId}")
    public Optional<Preference> getPreference(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Get preference of User " + userId);
        return preferenceService.getPreference(userId);
    }

    @PutMapping("/{userId}")
    public Preference updatePreference(@PathVariable Long userId, @RequestBody Preference preference) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Update preference of User " + userId);
        return preferenceService.updatePreference(userId, preference);
    }
}

