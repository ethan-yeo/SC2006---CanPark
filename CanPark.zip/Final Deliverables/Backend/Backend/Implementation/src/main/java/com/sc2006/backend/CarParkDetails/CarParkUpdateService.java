package com.sc2006.backend.CarParkDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CarParkUpdateService {
    
    @Autowired
    private CarParkRepository carParkRepository;

    @Autowired
    private WebClient webClient;

    @Transactional
    @Scheduled(fixedRate = 60000)
    public void updateCarParkData() {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Start Update Carpark");

        // Get set of carpark ids
        List<CarPark> carParksFromApi = fetchDataFromApi();
        Set<String> apiCarParkIds = carParksFromApi.stream().map(CarPark::getCarParkId).collect(Collectors.toSet());

        List<CarPark> existingCarParks = carParkRepository.findAll();
        Set<String> existingCarParkIds = existingCarParks.stream().map(CarPark::getCarParkId).collect(Collectors.toSet());

        existingCarParkIds.removeAll(apiCarParkIds);


        // Reset carparks for any removed carparkIds
        if (!existingCarParkIds.isEmpty()) {
            resetCarParks(existingCarParkIds);
        }

        carParkRepository.saveAll(carParksFromApi);
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": End Update Carpark");
    }

    private void resetCarParks(Set<String> carParkIds) {
        carParkIds.forEach(id -> carParkRepository.updateCarParkData(id, 0));
    }

    private List<CarPark> fetchDataFromApi() {
        Mono<CarParkAPIResponseDTO> carParkMono = webClient.get().uri("/CarParkAvailabilityv2").retrieve().bodyToMono(CarParkAPIResponseDTO.class);
        CarParkAPIResponseDTO carParkAPIResponseDTO = carParkMono.block();
        
        List<CarPark> carparks = new ArrayList<>();

        if (carParkAPIResponseDTO != null) {
            for (CarParkDTO dto : carParkAPIResponseDTO.getValue()) {
                dto.parseLocation();
                CarPark carPark = convertDtoToEntity(dto);
                carparks.add(carPark);
            }
        }
        return carparks;

    }

    private CarPark convertDtoToEntity(CarParkDTO dto) {
        CarPark carPark = new CarPark();

        carPark.setCarParkId(dto.getCarParkId()); // assuming carParkId in CarPark is of type int
        carPark.setLatitude(dto.getLatitude());
        carPark.setLongitude(dto.getLongitude());
        carPark.setArea(dto.getArea());
        carPark.setDevelopment(dto.getDevelopment());
        carPark.setAvailablelots(dto.getAvailableSlots()); 
        carPark.setLottypes(dto.getLottypes());
        carPark.setAgency(dto.getAgency());

        return carPark;
    }
}
