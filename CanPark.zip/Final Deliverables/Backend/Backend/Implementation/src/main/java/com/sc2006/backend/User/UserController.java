package com.sc2006.backend.User;

import com.sc2006.backend.Preference.PreferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private PreferenceService preferenceService;

    @PostMapping
    public User createUser(@RequestBody User user) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": createUser function");
        User newUser = userService.createUser(user); 
        preferenceService.createPreference(newUser.getId());
        return newUser;
    }

    @GetMapping
    public List<User> getAllUsers() {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": getAllUsers function");
        return userService.getAllUsers(); 
    }

    @GetMapping("/{userId}")
    public Optional<User> getUserById(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": getUserById function");
        return userService.getUserById(userId);
    }

    @PutMapping("/{userId}")
    public User updateUserById(@PathVariable Long userId, @RequestBody User userDetails) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": updateUserById function");
        return userService.updateUser(userId, userDetails);
    }

    @DeleteMapping
    public String deleteAllUsers() { 
        System.out.println("deleteAllUsers function");
        userService.deleteAllUsers();
        return "All users have been deleted";
    }

    @DeleteMapping("/{userId}")
    public void deleteUserById(@PathVariable Long userId) {
        System.out.println("deleteUserById function");
        userService.deleteUser(userId);
    }
}
