package com.sc2006.backend.Favourite;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.sc2006.backend.CarParkDetails.CarPark;
import com.sc2006.backend.User.User;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "favourites")
public class Favourite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long favId;
    
    @ManyToOne
    @JoinColumn(name = "car_park_id", nullable = false)
    private CarPark carPark;

    @JsonBackReference(value="UserToFav")
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public Long getId() { return favId; }
    public void setId(Long favId) { this.favId = favId; }

    public CarPark getFavourite() { return this.carPark; }
    public void setFavourite(CarPark carPark) { this.carPark = carPark; }

    public User getUser() { return this.user; }
    public void setUser(User user) { this.user = user; }
}