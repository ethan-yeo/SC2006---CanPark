package com.sc2006.backend.CarParkDetails;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${LTA_API_KEY}")
    private String apiKey;
    
    @Bean
    public WebClient webClient() {
        return WebClient.builder().baseUrl("http://datamall2.mytransport.sg/ltaodataservice").defaultHeader("AccountKey", apiKey).defaultHeader("accept", "application/json").build();
    }
}