package com.sc2006.backend.ParkedLocation;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParkedRepository extends JpaRepository<Parked, Long> {
    
}
