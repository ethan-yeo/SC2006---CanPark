package com.sc2006.backend.ParkedLocation;

import com.sc2006.backend.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Optional;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/parkedLocation")
public class ParkedController {
    @Autowired
    private UserService userService;

    @Autowired
    private ParkedService parkedService;

    // Create new parked location for a user
    @PostMapping("/{userId}/{carParkId}")
    public ResponseEntity<String> createParked(@PathVariable Long userId, @PathVariable String carParkId, @RequestBody Parked parked) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Create new parked location");
        parked.setId(userId);
        parked.setTime(LocalDateTime.now());
        return switch (parkedService.createParked(parked, carParkId)) {
            case 2 ->
                    new ResponseEntity<String>("User " + userId + " has already parked a location", HttpStatus.CONFLICT);
            case 3 -> new ResponseEntity<String>("Carpark id " + carParkId + " not found", HttpStatus.NOT_FOUND);
            case 4 -> new ResponseEntity<String>("User " + userId + " not found", HttpStatus.NOT_FOUND);
            default -> new ResponseEntity<String>("Parked location added for user " + userId, HttpStatus.OK);
        };
    }

    @GetMapping("/{userId}")
    public Optional<Parked> getParkedOfUser(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Getting Parked Location for User " + userId);
        return parkedService.getParked(userId);
    } 

    // Delete parked location
    @DeleteMapping("/{userId}")
    public void deleteParkedOfUser(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Delete Parked Location for User " + userId);
        parkedService.deleteParked(userId);
    }
}
