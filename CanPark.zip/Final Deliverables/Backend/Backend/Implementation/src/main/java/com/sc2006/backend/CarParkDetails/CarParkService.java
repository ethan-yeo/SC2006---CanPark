package com.sc2006.backend.CarParkDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CarParkService {
    @Autowired
    private CarParkRepository carParkRepository;

    public List<CarParkDTO> getAllCarParks() {
        return carParkRepository.findAll()
                .stream()
                .map(CarParkDTO::new)
                .collect(Collectors.toList());
    }

    public CarParkDTO getCarParkById(String carParkId){
        return new CarParkDTO(carParkRepository.findByCarParkId(carParkId).get());
    }
}
