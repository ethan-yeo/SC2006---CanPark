package com.sc2006.backend.Favourite;

import com.sc2006.backend.CarParkDetails.CarPark;
import com.sc2006.backend.CarParkDetails.CarParkRepository;
import com.sc2006.backend.ParkedLocation.ParkedRepository;
import com.sc2006.backend.User.User;
import com.sc2006.backend.User.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class FavouriteService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ParkedRepository parkedRepository;
    @Autowired
    private CarParkRepository carParkRepository;
    @Autowired
    private FavouriteRepository favouriteRepository;

    public int createFavourite(Long userId, String carParkId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": createFavourite function");
        Optional<Long> currFav = favouriteRepository.findFavByUserIdAndCarParkId(userId, carParkId);
        if(currFav.isPresent()){
            System.out.println("Favourites already exists");
            return -3;
        }
        Optional<User> currUser = userRepository.findById(userId);
        if(currUser.isEmpty()){
            System.out.println("User not found");
            return -2;
        }
        Optional<CarPark> currCarpark = carParkRepository.findByCarParkId(carParkId);
        if(currCarpark.isEmpty()) {
            System.out.println("carpark id not found");
            return -1;
        }

        // if no duplicate exists, user and carpark exists
        // Update User entity first
        System.out.println("Creating favourites");
        User newUser = currUser.get();

        Favourite newFavourite = new Favourite();
        newFavourite.setUser(newUser);
        newFavourite.setFavourite(currCarpark.get());

        newUser.addFavourite(newFavourite);

        favouriteRepository.save(newFavourite);
        System.out.println(Arrays.toString(newUser.getFavourite().toArray()));
        userRepository.save(newUser);

        // Add favourite location
        return 1;
    }

    public List<String> getFavourite(Long userId) {
        return favouriteRepository.findFavByUserId(userId);
    }

    public void clearUserFavourite(Long userid) {
        favouriteRepository.deleteByUserId(userid);
    }

    public void deleteFavourite(Long userid, String carparkId) {
        favouriteRepository.deleteByUserIdAndCarParkId(userid, carparkId);
    }
}
