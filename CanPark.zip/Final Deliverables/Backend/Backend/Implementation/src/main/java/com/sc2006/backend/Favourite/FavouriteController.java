package com.sc2006.backend.Favourite;

import com.sc2006.backend.User.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;

@RestController
@RequestMapping("/favourite")
public class FavouriteController {
    @Autowired
    private UserService userService;

    @Autowired
    private FavouriteService favouriteService;

    // New favourite location
    @GetMapping ("/{userId}/{carParkId}")
    public ResponseEntity<String> createFavourite(@PathVariable Long userId, @PathVariable String carParkId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Creating new favourite location");
        int created = favouriteService.createFavourite(userId, carParkId);
        switch (created) {
            case -1:
                return new ResponseEntity<String>("carpark id " + carParkId + " not found", HttpStatus.NOT_FOUND);
            case -2:
                return new ResponseEntity<String>("user id " + userId + " not found", HttpStatus.NOT_FOUND);
            case -3:
                return new ResponseEntity<String>("duplicate favourite found", HttpStatus.CONFLICT);        
            default:
                return ResponseEntity.ok("added "+ created +" favourites to user: "+ userId);
        } 
    }

    @GetMapping("/{userId}")
    public List<String> getFavourites(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Getting favourites of User " + userId);
        return favouriteService.getFavourite(userId);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<String> clearUserFavourite(@PathVariable Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Deleting all favorite locations with User ID " + userId);
        favouriteService.clearUserFavourite(userId);
        return ResponseEntity.ok("user favourites cleared");
    }

    @DeleteMapping("/{userid}/{carparkId}")
    public ResponseEntity<String> deleteFavourite(@PathVariable Long userid, @PathVariable String carparkId) {
        System.out.println("Deleting favorite location with User ID " + userid + " where carpark ID is " + carparkId);
        favouriteService.deleteFavourite(userid, carparkId);
        return ResponseEntity.ok("carpark id deleted");
    }
}
