package com.sc2006.backend.History;

import java.util.*;
import java.util.stream.Collectors;

import com.sc2006.backend.User.User;
import com.sc2006.backend.User.UserRepository;
import com.sc2006.backend.CarParkDetails.CarPark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc2006.backend.CarParkDetails.CarParkRepository;

@Service
public class ParkingHistoryService {
    @Autowired
    private ParkingHistoryRepository parkingHistoryRepository;

    @Autowired
    private CarParkRepository carParkRepository;

    @Autowired
    private UserRepository userRepository;

    public List<ParkingHistoryDTO> getHistoryByUser(User user) {
        return parkingHistoryRepository.findByUser(user)
                .stream()
                .map(ParkingHistoryDTO::new)
                .collect(Collectors.toList());
    }

    @Transactional
    public int deleteHistoryByUser(User user) {
        return parkingHistoryRepository.deleteByUser(user);
    }

    @Transactional
    public void addParkingHistory(ParkingHistoryDTO parkingHistoryDTO) {
        ParkingHistory parkingHistory = new ParkingHistory();
        Optional<CarPark> carPark = carParkRepository.findByCarParkId(parkingHistoryDTO.getCarParkId());
        if (carPark.isEmpty()){
            System.out.println("Carpark Not found!");
            return;
        }
        parkingHistory.setCarPark(carPark.get());
        parkingHistory.setStartTime(parkingHistoryDTO.getStartTime());
        parkingHistory.setEndTime(parkingHistoryDTO.getEndTime());
        parkingHistory.setTotalCost(parkingHistoryDTO.getTotalCost());

        Optional<User> user = userRepository.findByUserId(parkingHistoryDTO.getUserId());
        if(user.isEmpty()) {
            System.out.println("User Not found!");
            return;
        }
        parkingHistory.setUser(user.get());

        parkingHistoryRepository.save(parkingHistory);
    }
}
