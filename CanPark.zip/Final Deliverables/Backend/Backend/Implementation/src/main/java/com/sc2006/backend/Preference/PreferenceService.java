package com.sc2006.backend.Preference;

import com.sc2006.backend.User.User;
import com.sc2006.backend.User.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Optional;

@Service
public class PreferenceService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PreferenceRepository preferenceRepository;

    public void createPreference(Long userId) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": createPreference function");
        Preference pref = new Preference();
        pref.setId(userId);
        Optional<User> currUser = userRepository.findById(userId);

        if (currUser.isPresent()) {
            User user = currUser.get();
            pref.setUser(user);
            user.setPref(pref);

            userRepository.save(user);
            preferenceRepository.save(pref);
            return;
        }

        System.out.println("User not found");
    }

    public Optional<Preference> getPreference(Long id) {
        return preferenceRepository.findById(id);
    }

    public Preference updatePreference(Long id, Preference prefUpdate) {
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": updatePreference function");
        Optional<Preference> pref = preferenceRepository.findById(id);
        if(pref.isPresent()) {
            Preference currPref = pref.get();
            currPref.setRadius(prefUpdate.getRadius());
            currPref.setAvailability(prefUpdate.getAvailability());
            return preferenceRepository.save(currPref);
        }
        return null;
    }
}
