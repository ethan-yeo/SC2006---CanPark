package com.sc2006.backend.History;

import com.sc2006.backend.User.User;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.util.List;

@Repository
public interface ParkingHistoryRepository extends JpaRepository<ParkingHistory, Integer>{
    List<ParkingHistory> findByUser(User user);

    @Modifying
    @Transactional
    int deleteByUser(User user);
}
