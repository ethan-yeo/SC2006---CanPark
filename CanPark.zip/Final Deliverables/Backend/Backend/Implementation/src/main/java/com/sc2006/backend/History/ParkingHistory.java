package com.sc2006.backend.History;

import java.time.LocalDateTime;

import com.sc2006.backend.User.User;
import com.sc2006.backend.CarParkDetails.CarPark;
// import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonBackReference;

//import jakarta.persistence.CascadeType;
// import java.time.Duration;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class ParkingHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "parking_id")
    private int parkingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    @JsonBackReference(value="UserToHist")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_park_id")
    @JsonBackReference(value="CarParkToHist")
    private CarPark carPark;

    @Column(name = "start_time")
    private LocalDateTime startTime;
    @Column(name = "end_time")
    private LocalDateTime endTime;
    @Column(name = "total_cost")
    private double totalCost;
    @Column(name = "duration", insertable = false, updatable = false)
    private String duration;

    public int getParkingId(){
        return parkingId;
    }

    public User getUser() {
        return user;
    }

    public CarPark getCarPark() {
        return carPark;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public String getDuration() { return duration;}

    public void setUser(User user) {
        this.user = user;
    }

    public void setCarPark(CarPark carPark) {
        this.carPark = carPark;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
}
