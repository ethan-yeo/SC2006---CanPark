package com.sc2006.backend.ParkedLocation;

import com.sc2006.backend.CarParkDetails.CarPark;
import com.sc2006.backend.History.ParkingHistory;
import com.sc2006.backend.History.ParkingHistoryRepository;
import com.sc2006.backend.User.User;
import com.sc2006.backend.User.UserRepository;
import com.sc2006.backend.CarParkDetails.CarParkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Optional;

@Service
public class ParkedService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarParkRepository carParkRepository;

    @Autowired
    private ParkedRepository parkedRepository;

    @Autowired
    private ParkingHistoryRepository parkingHistoryRepository;

    public int createParked(Parked parked, String carParkId) {
        Optional<User> currUser = userRepository.findById(parked.getId());
        Optional<CarPark> carPark = carParkRepository.findById(carParkId);
        System.out.println(LocalTime.now(ZoneId.of("GMT+08:00")) + ": Create parked for a user");
        if (currUser.isEmpty()){
            System.out.println("User not found");
            return 4;
        } else if (carPark.isEmpty()) {
            System.out.println("Carpark not found");
            return 3;
        }

        User newUser = currUser.get();
        CarPark newPark = carPark.get();

        if (newUser.getParked() == null) {
            // Update User entity
            newUser.setParked(parked);
            parked.setUser(newUser);
            parked.setCarPark(newPark);
            userRepository.save(newUser);
            System.out.println("User saved");

            // Add parked location
            System.out.println("Saving now");
            return 1;
        } else {
            System.out.println("Already have parked location");
            return 2;
        }
    }

    public Optional<Parked> getParked(Long id) {
        return parkedRepository.findById(id);
    }

    public void deleteParked(Long id) {
        // Update User entity first
        Optional<User> currUser = userRepository.findById(id);
        if(currUser.isEmpty()){
            System.out.println("User not found");
            return;
        }
        currUser.get().setParked(null);
        userRepository.save(currUser.get());

        Optional<Parked> optParked = parkedRepository.findById(id);
        if(optParked.isEmpty()){
            System.out.println("Parked Location Not Found");
            return;
        }

        // Create new ParkingHistory
        Parked currParked = optParked.get();
        ParkingHistory newHist = new ParkingHistory();
        newHist.setCarPark(currParked.getCarPark());
        newHist.setUser(currParked.getUser());
        newHist.setTotalCost(0);

        // Set time for ParkingHistory
        LocalDateTime startTime = currParked.getTime();
        LocalDateTime endTime = LocalDateTime.now();

        newHist.setStartTime(startTime);
        newHist.setEndTime(endTime);

        parkingHistoryRepository.save(newHist);
        parkedRepository.deleteById(id);

    }
}
